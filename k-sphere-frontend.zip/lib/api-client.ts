// Client-side API helper functions

export class ApiClient {
  private static baseUrl = "/api"

  // System Status
  static async getSystemStatus() {
    const response = await fetch(`${this.baseUrl}/system-status`)
    if (!response.ok) throw new Error("Failed to fetch system status")
    return response.json()
  }

  // Knowledge Base
  static async getKnowledgeBase(params?: { type?: string; search?: string }) {
    const searchParams = new URLSearchParams()
    if (params?.type) searchParams.set("type", params.type)
    if (params?.search) searchParams.set("search", params.search)

    const response = await fetch(`${this.baseUrl}/knowledge-base?${searchParams}`)
    if (!response.ok) throw new Error("Failed to fetch knowledge base")
    return response.json()
  }

  static async getKnowledgeBaseStats() {
    const response = await fetch(`${this.baseUrl}/knowledge-base/stats`)
    if (!response.ok) throw new Error("Failed to fetch stats")
    return response.json()
  }

  static async uploadFile(file: File) {
    const formData = new FormData()
    formData.append("file", file)

    const response = await fetch(`${this.baseUrl}/knowledge-base`, {
      method: "POST",
      body: formData,
    })
    if (!response.ok) throw new Error("Failed to upload file")
    return response.json()
  }

  static async getFile(id: number) {
    const response = await fetch(`${this.baseUrl}/knowledge-base/${id}`)
    if (!response.ok) throw new Error("Failed to fetch file")
    return response.json()
  }

  static async deleteFile(id: number) {
    const response = await fetch(`${this.baseUrl}/knowledge-base/${id}`, {
      method: "DELETE",
    })
    if (!response.ok) throw new Error("Failed to delete file")
    return response.json()
  }

  // Chat
  static async sendMessage(message: string, conversationHistory: any[] = []) {
    const response = await fetch(`${this.baseUrl}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, conversationHistory }),
    })
    if (!response.ok) throw new Error("Failed to send message")
    return response.json()
  }

  static async sendMultimodalQuery(file: File, type: "image" | "audio", conversationHistory: any[] = []) {
    const formData = new FormData()
    formData.append("file", file)
    formData.append("type", type)
    formData.append("conversationHistory", JSON.stringify(conversationHistory))

    const response = await fetch(`${this.baseUrl}/chat/multimodal`, {
      method: "POST",
      body: formData,
    })
    if (!response.ok) throw new Error("Failed to send multimodal query")
    return response.json()
  }

  // Settings
  static async getSettings() {
    const response = await fetch(`${this.baseUrl}/settings`)
    if (!response.ok) throw new Error("Failed to fetch settings")
    return response.json()
  }

  static async updateSettings(settings: any) {
    const response = await fetch(`${this.baseUrl}/settings`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(settings),
    })
    if (!response.ok) throw new Error("Failed to update settings")
    return response.json()
  }

  // Ingestion
  static async triggerIngestion(fileId: number) {
    const response = await fetch(`${this.baseUrl}/ingestion/trigger`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fileId }),
    })
    if (!response.ok) throw new Error("Failed to trigger ingestion")
    return response.json()
  }
}
