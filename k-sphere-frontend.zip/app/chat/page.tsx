"use client"

import { AppSidebar } from "@/components/app-sidebar"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Send, ImageIcon, Mic, FileText, ExternalLink } from "lucide-react"
import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"

interface Message {
  id: number
  role: "user" | "assistant"
  content: string
  sources?: Array<{
    name: string
    type: string
    relevance: number
  }>
  timestamp: string
}

const mockMessages: Message[] = [
  {
    id: 1,
    role: "user",
    content: "What are the key principles of machine learning?",
    timestamp: "10:30 AM",
  },
  {
    id: 2,
    role: "assistant",
    content:
      "Based on your knowledge base, the key principles of machine learning include:\n\n1. **Supervised Learning**: Training models on labeled data to make predictions\n2. **Unsupervised Learning**: Finding patterns in unlabeled data\n3. **Feature Engineering**: Selecting and transforming relevant input variables\n4. **Model Evaluation**: Using metrics like accuracy, precision, and recall\n5. **Generalization**: Ensuring models perform well on unseen data\n\nThese principles form the foundation for building effective ML systems.",
    sources: [
      { name: "machine_learning_fundamentals.pdf", type: "document", relevance: 0.95 },
      { name: "research_paper_draft.pdf", type: "document", relevance: 0.82 },
      { name: "technical_specification.pdf", type: "document", relevance: 0.76 },
    ],
    timestamp: "10:30 AM",
  },
  {
    id: 3,
    role: "user",
    content: "Can you explain the neural network architecture shown in my diagrams?",
    timestamp: "10:32 AM",
  },
  {
    id: 4,
    role: "assistant",
    content:
      "The neural network architecture in your diagrams shows a deep learning model with the following structure:\n\n**Input Layer**: Receives raw data (784 neurons for 28x28 images)\n**Hidden Layers**: Three fully connected layers with 512, 256, and 128 neurons respectively, using ReLU activation\n**Output Layer**: 10 neurons with softmax activation for classification\n\nThe architecture uses dropout layers (0.2 rate) between hidden layers to prevent overfitting. This is a classic feedforward neural network design suitable for image classification tasks.",
    sources: [
      { name: "neural_network_diagram.png", type: "image", relevance: 0.98 },
      { name: "architecture_blueprint.png", type: "image", relevance: 0.88 },
    ],
    timestamp: "10:32 AM",
  },
]

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("k-sphere-chat-messages")
      return saved ? JSON.parse(saved) : mockMessages
    }
    return mockMessages
  })
  const [inputValue, setInputValue] = useState("")

  useEffect(() => {
    localStorage.setItem("k-sphere-chat-messages", JSON.stringify(messages))
  }, [messages])

  const handleSend = () => {
    if (!inputValue.trim()) return

    const newMessage: Message = {
      id: messages.length + 1,
      role: "user",
      content: inputValue,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setMessages([...messages, newMessage])
    setInputValue("")
  }

  const getSourceIcon = (type: string) => {
    switch (type) {
      case "document":
        return <FileText className="h-3 w-3" />
      case "image":
        return <ImageIcon className="h-3 w-3" />
      case "audio":
        return <Mic className="h-3 w-3" />
      default:
        return <FileText className="h-3 w-3" />
    }
  }

  return (
    <div className="flex h-screen">
      <AppSidebar />

      <main className="flex flex-1 flex-col">
        <div className="border-b border-border bg-card px-8 py-4">
          <h1 className="text-xl font-semibold text-foreground">Chat</h1>
          <p className="text-sm text-muted-foreground">Ask questions about your knowledge base</p>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-8">
          <div className="mx-auto max-w-4xl space-y-6">
            {messages.map((message) => (
              <div
                key={message.id}
                className={cn("flex gap-4", message.role === "user" ? "justify-end" : "justify-start")}
              >
                {message.role === "assistant" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary">
                    <span className="font-mono text-xs font-bold text-primary-foreground">K</span>
                  </div>
                )}

                <div className={cn("flex max-w-[80%] flex-col gap-2", message.role === "user" && "items-end")}>
                  <Card
                    className={cn(
                      "border-border p-4",
                      message.role === "user" ? "bg-primary text-primary-foreground" : "bg-card",
                    )}
                  >
                    <p
                      className={cn(
                        "whitespace-pre-wrap text-sm leading-relaxed",
                        message.role === "user" ? "text-primary-foreground" : "text-foreground",
                      )}
                    >
                      {message.content}
                    </p>
                  </Card>

                  {message.sources && message.sources.length > 0 && (
                    <div className="flex flex-col gap-2">
                      <p className="text-xs font-medium text-muted-foreground">Sources:</p>
                      <div className="flex flex-wrap gap-2">
                        {message.sources.map((source, index) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className="cursor-pointer border-border bg-card text-foreground hover:bg-muted"
                          >
                            <div className="flex items-center gap-2">
                              {getSourceIcon(source.type)}
                              <span className="text-xs">{source.name}</span>
                              <span className="text-xs text-muted-foreground">
                                {Math.round(source.relevance * 100)}%
                              </span>
                              <ExternalLink className="h-3 w-3" />
                            </div>
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  <span className="text-xs text-muted-foreground">{message.timestamp}</span>
                </div>

                {message.role === "user" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted">
                    <span className="text-xs font-medium text-foreground">You</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Input Area */}
        <div className="border-t border-border bg-card p-6">
          <div className="mx-auto max-w-4xl">
            <div className="flex items-end gap-3">
              <div className="flex gap-2">
                <Button variant="outline" size="icon" className="h-10 w-10 border-border hover:bg-muted bg-transparent">
                  <ImageIcon className="h-5 w-5" />
                </Button>
                <Button variant="outline" size="icon" className="h-10 w-10 border-border hover:bg-muted bg-transparent">
                  <Mic className="h-5 w-5" />
                </Button>
              </div>

              <div className="flex-1">
                <Input
                  placeholder="Ask a question about your knowledge base..."
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      handleSend()
                    }
                  }}
                  className="min-h-[40px] resize-none border-border bg-background text-foreground"
                />
              </div>

              <Button
                onClick={handleSend}
                disabled={!inputValue.trim()}
                className="h-10 bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <Send className="h-5 w-5" />
              </Button>
            </div>

            <p className="mt-3 text-center text-xs text-muted-foreground">
              K-Sphere uses your local knowledge base to answer questions. All processing happens offline.
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
