import { NextResponse } from "next/server"

export async function GET() {
  try {
    // TODO: Replace with actual database queries
    const stats = {
      totalDocuments: 1247,
      totalImages: 3892,
      totalAudio: 156,
      totalSize: 48547020800, // bytes (45.2 GB)
      totalChunks: 15847,
      recentActivity: [
        {
          id: 1,
          action: "Document indexed",
          file: "research_paper_2024.pdf",
          time: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
          type: "document",
        },
        {
          id: 2,
          action: "Image processed",
          file: "diagram_architecture.png",
          time: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
          type: "image",
        },
        {
          id: 3,
          action: "Audio transcribed",
          file: "meeting_notes.mp3",
          time: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
          type: "audio",
        },
        {
          id: 4,
          action: "Query processed",
          file: "What is machine learning?",
          time: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          type: "query",
        },
        {
          id: 5,
          action: "Document indexed",
          file: "technical_spec.pdf",
          time: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
          type: "document",
        },
      ],
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error("[v0] Stats fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch stats" }, { status: 500 })
  }
}
