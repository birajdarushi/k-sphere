import { NextResponse } from "next/server"

export async function GET() {
  try {
    // TODO: Replace with actual system status checks
    const systemStatus = {
      embeddingModel: {
        name: "all-MiniLM-L6-v2",
        status: "online",
        lastCheck: new Date().toISOString(),
      },
      llmModel: {
        name: "Llama-3.2-3B",
        status: "online",
        lastCheck: new Date().toISOString(),
      },
      vectorDatabase: {
        name: "ChromaDB",
        status: "online",
        lastCheck: new Date().toISOString(),
      },
    }

    return NextResponse.json(systemStatus)
  } catch (error) {
    console.error("[v0] System status error:", error)
    return NextResponse.json({ error: "Failed to fetch system status" }, { status: 500 })
  }
}
