"use client"

import { useState } from "react"
import { AppSidebar } from "@/components/app-sidebar"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Database, Cpu, HardDrive, SettingsIcon } from "lucide-react"

export default function SettingsPage() {
  const [watchDirectory, setWatchDirectory] = useState("/data/input")
  const [chunkSize, setChunkSize] = useState("512")
  const [chunkOverlap, setChunkOverlap] = useState("50")
  const [topKResults, setTopKResults] = useState("5")

  const handleSaveSettings = () => {
    console.log("[v0] Saving settings:", {
      watchDirectory,
      chunkSize,
      chunkOverlap,
      topKResults,
    })
    // TODO: Implement actual settings save
  }

  return (
    <div className="flex h-screen">
      <AppSidebar />

      <main className="flex-1 overflow-y-auto">
        <div className="container mx-auto p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground">Settings</h1>
            <p className="mt-2 text-muted-foreground">Configure your K-Sphere system</p>
          </div>

          {/* Model Configuration */}
          <div className="mb-8">
            <h2 className="mb-4 text-lg font-semibold text-foreground">Model Configuration</h2>
            <div className="grid gap-4 md:grid-cols-2">
              <Card className="border-border bg-card p-6">
                <div className="mb-4 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-1/10">
                    <Cpu className="h-5 w-5 text-chart-1" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">LLM Model</h3>
                    <Badge variant="outline" className="mt-1 border-chart-2 bg-chart-2/10 text-chart-2">
                      Active
                    </Badge>
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <Label className="text-sm text-muted-foreground">Model Name</Label>
                    <Input value="Llama-3.2-3B" readOnly className="mt-1 border-border bg-muted text-foreground" />
                  </div>
                  <div>
                    <Label className="text-sm text-muted-foreground">Model Path</Label>
                    <Input
                      value="/models/llama-3.2-3b.gguf"
                      readOnly
                      className="mt-1 border-border bg-muted text-foreground"
                    />
                  </div>
                </div>
              </Card>

              <Card className="border-border bg-card p-6">
                <div className="mb-4 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-2/10">
                    <Database className="h-5 w-5 text-chart-2" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Embedding Model</h3>
                    <Badge variant="outline" className="mt-1 border-chart-2 bg-chart-2/10 text-chart-2">
                      Active
                    </Badge>
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <Label className="text-sm text-muted-foreground">Model Name</Label>
                    <Input value="all-MiniLM-L6-v2" readOnly className="mt-1 border-border bg-muted text-foreground" />
                  </div>
                  <div>
                    <Label className="text-sm text-muted-foreground">Dimension</Label>
                    <Input value="384" readOnly className="mt-1 border-border bg-muted text-foreground" />
                  </div>
                </div>
              </Card>
            </div>
          </div>

          {/* Storage Configuration */}
          <div className="mb-8">
            <h2 className="mb-4 text-lg font-semibold text-foreground">Storage Configuration</h2>
            <Card className="border-border bg-card p-6">
              <div className="mb-4 flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-4/10">
                  <HardDrive className="h-5 w-5 text-chart-4" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Vector Database</h3>
                  <Badge variant="outline" className="mt-1 border-chart-2 bg-chart-2/10 text-chart-2">
                    Connected
                  </Badge>
                </div>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="text-sm text-muted-foreground">Database Type</Label>
                  <Input value="ChromaDB" readOnly className="mt-1 border-border bg-muted text-foreground" />
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">Storage Path</Label>
                  <Input value="/data/chroma" readOnly className="mt-1 border-border bg-muted text-foreground" />
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">Collection Name</Label>
                  <Input value="k-sphere-knowledge" readOnly className="mt-1 border-border bg-muted text-foreground" />
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">Total Vectors</Label>
                  <Input value="15,847" readOnly className="mt-1 border-border bg-muted text-foreground" />
                </div>
              </div>
            </Card>
          </div>

          {/* System Settings */}
          <div>
            <h2 className="mb-4 text-lg font-semibold text-foreground">System Settings</h2>
            <Card className="border-border bg-card p-6">
              <div className="mb-4 flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <SettingsIcon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground">General Settings</h3>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="text-sm text-muted-foreground">Watch Directory</Label>
                  <Input
                    value={watchDirectory}
                    onChange={(e) => setWatchDirectory(e.target.value)}
                    className="mt-1 border-border bg-background text-foreground"
                  />
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">Chunk Size</Label>
                  <Input
                    value={chunkSize}
                    onChange={(e) => setChunkSize(e.target.value)}
                    className="mt-1 border-border bg-background text-foreground"
                  />
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">Chunk Overlap</Label>
                  <Input
                    value={chunkOverlap}
                    onChange={(e) => setChunkOverlap(e.target.value)}
                    className="mt-1 border-border bg-background text-foreground"
                  />
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">Top K Results</Label>
                  <Input
                    value={topKResults}
                    onChange={(e) => setTopKResults(e.target.value)}
                    className="mt-1 border-border bg-background text-foreground"
                  />
                </div>
              </div>
              <div className="mt-6 flex justify-end">
                <Button onClick={handleSaveSettings} className="bg-primary text-primary-foreground hover:bg-primary/90">
                  Save Changes
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
